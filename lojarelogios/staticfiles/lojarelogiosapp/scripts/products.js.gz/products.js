var successDiv = document.getElementById('success-div')

setTimeout(() => successDiv.style.display = 'none', 3000)

var errorDiv = document.getElementById('error-div')

setTimeout(() => errorDiv.style.display = 'none', 3000)